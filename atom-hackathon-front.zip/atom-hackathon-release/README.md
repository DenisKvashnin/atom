# ApeEd Frontend

### Для запуска
```
npm install
npm run serve
```

### Сборка
```
npm run build
```
