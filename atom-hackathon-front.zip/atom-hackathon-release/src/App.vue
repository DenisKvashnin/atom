<template>
    <v-app>
        <router-view />
    </v-app>
</template>

<style>
a {
	color: inherit;
	text-decoration: none;
}

.wrapper {
	width: 1400px;
	margin: 0 auto;
}
</style>
