package ru.atom.hachaton.model.dto;

import lombok.Data;

@Data
public class OrgCountTypeDto {
    private String nameRu;
    private String eduType;
    private Integer countOrg;
}