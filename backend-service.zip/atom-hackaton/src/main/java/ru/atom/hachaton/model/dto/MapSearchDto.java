package ru.atom.hachaton.model.dto;

import lombok.Data;

@Data
public class MapSearchDto {
    private Long id;
    private String fullName;
    private String population;
}
