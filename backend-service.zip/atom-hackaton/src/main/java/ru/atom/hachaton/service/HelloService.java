package ru.atom.hachaton.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
}
