CREATE INDEX idx_map_search ON map_info(region, settlement);
