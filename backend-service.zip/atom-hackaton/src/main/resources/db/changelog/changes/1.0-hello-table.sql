CREATE TABLE IF NOT EXISTS hello(
    id bigint PRIMARY  KEY,
    name character varying
);