ALTER TABLE organization ADD COLUMN lat real;
ALTER TABLE organization ADD COLUMN lon real;